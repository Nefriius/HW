//function to calc tip
function calcTip(mealAmnt, tipPerc){
    return mealAmnt * tipPerc;
}

function calcTotal(mealAmnt, tipAmnt){
    return mealAmnt + tipAmnt;
}

function isValid(mealAmnt, tipPerc){
    let msg = "";
    //test one error at a time w/if
    if(isNaN(mealAmnt)){
        msg += "Please enter a numeric meal amount\n";
    }
    if(mealAmnt < 1){
        msg += "Please enter a meal amount greater than 0\n";
    }
    if(tipPerc == 0){
        msg += "Select a tip percent";
    }
    return msg;
}

document.getElementById("btnCalcTip").addEventListener('click', function(){
    //inputs
    let meal = parseFloat(document.getElementById("numMeal").value);
    let perc = parseFloat(document.getElementById("cboPercent").value);
    let errors = isValid(meal, perc);

    //processing
    if(errors == ""){
        let tip = calcTip(meal, perc);
        let total = calcTotal(meal, tip);
        //output result
        alert(`The tip is $${tip.toFixed(2)} and the meal total is: $${total.toFixed(2)}`);
    }else{
        alert(errors);
    } 
});

